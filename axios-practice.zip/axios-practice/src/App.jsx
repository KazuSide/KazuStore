import { useState, useEffect, useRef } from 'react';
import axios from 'axios';

// --- Komponen SVG Icons Pembantu ---
const Icons = {
  Cart: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
  Star: ({ filled }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${filled ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} viewBox="0 0 20 20" fill="currentColor">
      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
    </svg>
  ),
  Search: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 0 0114 0z" />
    </svg>
  ),
  Close: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  Trash: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
  ),
  Refresh: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 animate-spin-reverse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 19.5" />
    </svg>
  ),
  Info: () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  )
};

export default function App() {
  // --- State Utama ---
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // State untuk Filter & Pencarian
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('default');
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000 });
  const [minRating, setMinRating] = useState(0);

  // State Keranjang Belanja (Simulasi)
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // State Modal Detail Produk
  const [selectedProduct, setSelectedProduct] = useState(null);

  // State Notifikasi Toast
  const [toasts, setToasts] = useState([]);
  // Ref untuk menghasilkan ID toast secara murni
  const toastIdRef = useRef(0);

  // --- Ambil Data dari API ---
  const fetchInitialData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Mengambil Produk dan Kategori secara bersamaan (Concurrent Request)
      const [productsResponse, categoriesResponse] = await Promise.all([
        axios.get('https://fakestoreapi.com/products'),
        axios.get('https://fakestoreapi.com/products/categories')
      ]);

      setProducts(productsResponse.data);
      setCategories(categoriesResponse.data);

      // Menyetel batas harga maksimal slider secara dinamis
      const prices = productsResponse.data.map(p => p.price);
      const maxPrice = Math.ceil(Math.max(...prices));
      setPriceRange(prev => ({ ...prev, max: maxPrice }));

    } catch (err) {
      console.error('Koneksi API Error:', err);
      setError('Gagal memuat katalog produk. Pastikan jaringan internet Anda aktif.');
    } finally {
      setLoading(false);
    }
  };

   useEffect(() => {
    // Defer the initial fetch to avoid synchronous setState inside effect
    const t = setTimeout(() => {
      fetchInitialData();
    }, 0);
    return () => clearTimeout(t);
  }, []);

  // Mengambil data kategori secara dinamis (Menjawab Ketentuan API di Modul)
  const handleCategoryChange = async (category) => {
    setSelectedCategory(category);
    try {
      setLoading(true);
      setError(null);
      let url = 'https://fakestoreapi.com/products';
      if (category !== 'all') {
        url = `https://fakestoreapi.com/products/category/${encodeURIComponent(category)}`;
      }
      const response = await axios.get(url);
      setProducts(response.data);
    } catch (err) {
      console.error('Error mengambil data kategori:', err);
      setError('Gagal memuat produk dari kategori terpilih.');
    } finally {
      setLoading(false);
    }
  };

  // --- Fungsi Toast Notifikasi ---
  const showToast = (message, type = 'success') => {
    const id = ++toastIdRef.current;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(toast => toast.id !== id));
    }, 3000);
  };

  // --- Fungsi Keranjang ---
  const addToCart = (product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { product, quantity: 1 }];
    });
    showToast(`"${product.title.substring(0, 20)}..." ditambahkan ke keranjang!`);
  };

  const removeFromCart = (productId) => {
    setCart(prevCart => prevCart.filter(item => item.product.id !== productId));
    showToast('Produk dihapus dari keranjang.', 'info');
  };

  const updateCartQuantity = (productId, change) => {
    setCart(prevCart => {
      return prevCart.map(item => {
        if (item.product.id === productId) {
          const newQty = item.quantity + change;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const clearCart = () => {
    setCart([]);
    showToast('Keranjang belanja telah dikosongkan.', 'info');
  };

  // --- Filter & Pengurutan ---
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPrice = product.price >= priceRange.min && product.price <= priceRange.max;
    const matchesRating = product.rating.rate >= minRating;

    return matchesSearch && matchesPrice && matchesRating;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'rating-desc') return b.rating.rate - a.rating.rate;
    return 0;
  });

  const cartTotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const cartItemCount = cart.reduce((count, item) => count + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      
      {/* --- HEADER NAVBAR --- */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-2xl font-black bg-gradient-to-r from-blue-600 to-indigo-600 text-transparent bg-clip-text">
              KazuStore
            </span>
            <span className="hidden sm:inline-block bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded font-medium">
              Katalog Produk KazuStore
            </span>
          </div>

          <button 
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center space-x-2 px-4 py-2 rounded-full bg-slate-100 hover:bg-blue-50 hover:text-blue-600 transition-colors duration-200"
          >
            <Icons.Cart />
            <span className="hidden sm:inline font-semibold">Keranjang</span>
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full font-bold animate-pulse">
                {cartItemCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* --- TOAST NOTIFICATION --- */}
      <div className="fixed bottom-5 right-5 z-50 space-y-2 pointer-events-none max-w-sm">
        {toasts.map(toast => (
          <div 
            key={toast.id} 
            className={`p-4 rounded-xl shadow-lg flex items-center justify-between space-x-3 transition-all duration-300 transform translate-y-0 opacity-100 pointer-events-auto border ${
              toast.type === 'success' 
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}
          >
            <span className="text-sm font-medium">{toast.message}</span>
            <button 
              onClick={() => setToasts(prev => prev.filter(t => t.id !== toast.id))}
              className="text-slate-400 hover:text-slate-600"
            >
              <Icons.Close />
            </button>
          </div>
        ))}
      </div>

      {/* --- HERO SECTION --- */}
      <section className="bg-gradient-to-r from-indigo-900 via-blue-950 to-slate-950 text-white py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-3xl sm:text-5xl font-extrabold mb-4 tracking-tight">
            Selamat Datang di KazuStore!
          </h1>
          <p className="text-md sm:text-lg text-slate-300 max-w-2xl mx-auto font-light">
            Solusi untuk memenuhi kebutuhan belanja online Anda.
          </p>
        </div>
      </section>

      {/* --- MAIN LAYOUT --- */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {error && (
          <div className="mb-8 p-6 bg-red-50 border border-red-200 rounded-2xl text-center max-w-2xl mx-auto">
            <span className="text-4xl">⚠️</span>
            <h3 className="text-lg font-bold text-red-900 mt-2">Terjadi Kesalahan</h3>
            <p className="text-red-700 text-sm mt-1 mb-4">{error}</p>
            <button 
              onClick={fetchInitialData} 
              className="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-semibold rounded-lg transition-colors shadow-sm"
            >
              <Icons.Refresh /> Coba Muat Ulang
            </button>
          </div>
        )}

        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          
          {/* --- SIDEBAR FILTER --- */}
          <aside className="lg:col-span-1 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-fit mb-8 lg:mb-0 space-y-6">
            <div>
              <h3 className="font-bold text-lg text-slate-900 mb-4 flex items-center justify-between">
                <span>Filter & Cari</span>
                <button 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setSortBy('default');
                    setMinRating(0);
                    setPriceRange({ min: 0, max: 1000 });
                  }}
                  className="text-xs text-blue-600 hover:underline font-medium"
                >
                  Reset Semua
                </button>
              </h3>
              
              <div className="relative">
                <input
                  type="text"
                  placeholder="Cari nama produk..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
                <span className="absolute left-3 top-3">
                  <Icons.Search />
                </span>
              </div>
            </div>

            {/* Kategori */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                Kategori Produk
              </label>
              <div className="space-y-1">
                <button
                  onClick={() => handleCategoryChange('all')}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedCategory === 'all' 
                      ? 'bg-blue-600 text-white font-semibold shadow-sm' 
                      : 'bg-transparent text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Semua Produk
                </button>
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => handleCategoryChange(category)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm capitalize transition-colors ${
                      selectedCategory === category 
                        ? 'bg-blue-600 text-white font-semibold shadow-sm' 
                        : 'bg-transparent text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Sorting */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Urutkan Produk
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="default">Default</option>
                <option value="price-asc">Harga: Rendah ke Tinggi</option>
                <option value="price-desc">Harga: Tinggi ke Rendah</option>
                <option value="rating-desc">Rating Tertinggi</option>
              </select>
            </div>

            {/* Price Slider */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Harga Maksimal ($)
                </label>
                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  ${priceRange.max}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="1000"
                value={priceRange.max}
                onChange={(e) => setPriceRange(prev => ({ ...prev, max: Number(e.target.value) }))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            {/* Rating Filter */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Rating Minimal
              </label>
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setMinRating(star)}
                    className="p-1 transition-transform active:scale-95"
                  >
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className={`h-6 w-6 ${star <= minRating ? 'text-yellow-400 fill-current' : 'text-slate-200'}`} 
                      viewBox="0 0 20 20" 
                      fill="currentColor"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* --- DAFTAR PRODUK --- */}
          <section className="lg:col-span-3">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="w-12 h-12 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin"></div>
                <p className="mt-4 text-slate-500 font-medium">Memuat data...</p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between mb-6">
                  <span className="text-sm font-semibold text-slate-500">
                    Menampilkan <span className="text-slate-950 font-bold">{filteredProducts.length}</span> produk
                  </span>
                </div>

                {filteredProducts.length === 0 && (
                  <div className="text-center py-16 bg-white border border-slate-200 rounded-3xl p-8 max-w-lg mx-auto">
                    <span className="text-5xl">🔍</span>
                    <h3 className="text-lg font-bold text-slate-900 mt-4">Tidak Ditemukan</h3>
                    <p className="text-slate-500 text-sm mt-1">Coba sesuaikan kriteria pencarian atau filter Anda.</p>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <div 
                      key={product.id}
                      className="group bg-white rounded-2xl border border-slate-150 p-4 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                    >
                      <div>
                        <div 
                          className="w-full h-48 rounded-xl overflow-hidden bg-white flex items-center justify-center p-2 cursor-pointer relative"
                          onClick={() => setSelectedProduct(product)}
                        >
                          <img 
                            src={product.image} 
                            alt={product.title} 
                            className="h-full object-contain group-hover:scale-105 transition-transform duration-300"
                            loading="lazy"
                          />
                        </div>

                        <div className="mt-4">
                          <h3 
                            onClick={() => setSelectedProduct(product)}
                            className="text-sm font-bold text-slate-800 line-clamp-2 hover:text-blue-600 cursor-pointer min-h-[40px]"
                          >
                            {product.title}
                          </h3>
                          <div className="flex items-center space-x-1 mt-2">
                            <div className="flex items-center">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Icons.Star 
                                  key={star} 
                                  filled={star <= Math.round(product.rating.rate)} 
                                />
                              ))}
                            </div>
                            <span className="text-xs font-semibold text-slate-500">
                              {product.rating.rate} ({product.rating.count})
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-semibold uppercase">Harga</span>
                          <span className="text-lg font-black text-slate-900">${product.price.toFixed(2)}</span>
                        </div>
                        <button 
                          onClick={() => addToCart(product)}
                          className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs flex items-center space-x-1.5 transition-all active:scale-95 shadow-md shadow-blue-200"
                        >
                          <Icons.Cart />
                          <span>Beli</span>
                        </button>
                      </div>

                    </div>
                  ))}
                </div>
              </>
            )}
          </section>
        </div>
      </main>

      {/* --- MODAL DETAIL PRODUK --- */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
          <div 
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
            onClick={() => setSelectedProduct(null)}
          ></div>

          <div className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-2xl w-full relative z-10 border border-slate-200 transform scale-100 transition-transform">
            <div className="p-4 sm:p-6 border-b border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">
                {selectedProduct.category}
              </span>
              <button 
                onClick={() => setSelectedProduct(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <Icons.Close />
              </button>
            </div>

            <div className="p-6 sm:grid sm:grid-cols-2 sm:gap-6">
              <div className="flex items-center justify-center bg-slate-50 rounded-2xl p-4 h-64 sm:h-auto mb-4 sm:mb-0">
                <img 
                  src={selectedProduct.image} 
                  alt={selectedProduct.title} 
                  className="max-h-full max-w-full object-contain"
                />
              </div>

              <div className="flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-black text-slate-900 leading-snug">
                    {selectedProduct.title}
                  </h3>
                  <p className="text-sm text-slate-500 mt-4 leading-relaxed">
                    {selectedProduct.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block font-semibold uppercase">Total Harga</span>
                    <span className="text-2xl font-black text-slate-900">${selectedProduct.price.toFixed(2)}</span>
                  </div>
                  <button 
                    onClick={() => {
                      addToCart(selectedProduct);
                      setSelectedProduct(null);
                    }}
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm flex items-center space-x-2 transition-transform active:scale-95 shadow-md shadow-blue-200"
                  >
                    <Icons.Cart />
                    <span>Masukkan Keranjang</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- DRAWER KERANJANG BELANJA --- */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div 
            className="absolute inset-0 bg-slate-950/50 backdrop-blur-sm transition-opacity"
            onClick={() => setIsCartOpen(false)}
          ></div>

          <div className="absolute inset-y-0 right-0 max-w-full flex">
            <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col h-full border-l border-slate-200">
              <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between">
                <h2 className="text-lg font-black text-slate-900 flex items-center space-x-2">
                  <Icons.Cart />
                  <span>Keranjang Belanja</span>
                </h2>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  <Icons.Close />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-20 flex flex-col items-center justify-center">
                    <span className="text-4xl mb-2">🛒</span>
                    <p className="text-slate-500 font-medium">Keranjang belanja Anda kosong.</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div 
                      key={item.product.id} 
                      className="flex items-center space-x-4 p-3 bg-slate-50 rounded-xl border border-slate-100"
                    >
                      <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center p-1.5 border border-slate-150 flex-shrink-0">
                        <img 
                          src={item.product.image} 
                          alt={item.product.title} 
                          className="max-h-full max-w-full object-contain"
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold text-slate-800 truncate">
                          {item.product.title}
                        </h4>
                        <span className="text-xs text-slate-400 font-semibold block">
                          ${item.product.price.toFixed(2)}
                        </span>
                        
                        <div className="flex items-center space-x-2 mt-2">
                          <button 
                            onClick={() => updateCartQuantity(item.product.id, -1)}
                            className="w-6 h-6 rounded-md bg-white border border-slate-250 hover:bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600"
                          >
                            -
                          </button>
                          <span className="text-xs font-bold text-slate-800 w-4 text-center">
                            {item.quantity}
                          </span>
                          <button 
                            onClick={() => updateCartQuantity(item.product.id, 1)}
                            className="w-6 h-6 rounded-md bg-white border border-slate-250 hover:bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="flex flex-col items-end justify-between h-full">
                        <span className="text-sm font-black text-slate-900">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </span>
                        <button 
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-slate-400 hover:text-red-500 transition-colors mt-2"
                        >
                          <Icons.Trash />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="border-t border-slate-200 p-6 bg-slate-50 space-y-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-slate-500 font-medium">Subtotal</span>
                    <span className="text-xl font-black text-slate-900">${cartTotal.toFixed(2)}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={clearCart}
                      className="px-4 py-3 border border-slate-250 text-slate-600 font-bold rounded-xl text-xs hover:bg-slate-100 transition-colors"
                    >
                      Kosongkan
                    </button>
                    <button 
                      onClick={() => {
                        showToast('Checkout Belanja Berhasil!');
                        clearCart();
                        setIsCartOpen(false);
                      }}
                      className="px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-200"
                    >
                      Checkout Belanja
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- FOOTER --- */}
      <footer className="bg-slate-900 text-slate-400 py-12 mt-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:flex sm:items-center sm:justify-between">
          <div className="mb-4 sm:mb-0">
            <span className="text-xl font-black text-white">WarungFake</span>
            <p className="text-xs text-slate-500 mt-1">© 2026 Universitas Amikom Yogyakarta. ST084.</p>
          </div>
          <div className="flex items-center justify-center space-x-6 text-xs font-semibold">
            <span className="hover:text-white transition-colors">24.11.6103 - Rafael Rega Purnomo Aji</span>
          </div>
        </div>
      </footer>

    </div>
  );
}